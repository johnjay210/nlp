# NLP Weeks 1–6 Tasks

This repository contains Python implementations of Natural Language Processing (NLP) tasks for Weeks 1–6.

## Topics Covered
- Sentence Tokenization
- Word Frequency Counter
- Trigram Language Model
- POS Tagging Mad Libs
- Named Entity Recognition
- Next Word Prediction
- Grammar Parsing
- Sentence Generation
- NLP Pipeline
- Information Extraction

## Requirements
Install required libraries:

pip install nltk spacy
python -m spacy download en_core_web_sm

## Running Example
python week1_sentence_tokenization.py